﻿using Microsoft.AspNetCore.Mvc;
using CurrencyConverter.Core.Interfaces;

namespace CurrencyConverter.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CurrencyController : ControllerBase
    {
        private readonly ICurrencyService _currencyService;

        public CurrencyController(ICurrencyService currencyService)
        {
            _currencyService = currencyService;
        }

        [HttpGet("currencies")]
        public async Task<IActionResult> GetCurrencies()
        {
            var currencies = await _currencyService.GetCurrencyRatesAsync();
            var response = currencies.Select(c => new
            {
                c.Code,
                c.Name,
                c.Rate,
                c.Quantity
            });
            return Ok(new { currencies = response });
        }

        [HttpPost("convert")]
        public async Task<IActionResult> ConvertCurrency([FromBody] ConversionRequest request)
        {
            if (request.Amount <= 0 || request.Amount > 999_999_999.99m)
            {
                return BadRequest(new { error = new { code = "INVALID_AMOUNT", message = "Amount must be greater than 0 and less than or equal to 999,999,999.99" } });
            }

            try
            {
                var convertedAmount = await _currencyService.ConvertCurrencyAsync(request.Amount, request.FromCurrency, request.ToCurrency);
                var response = new ConversionRequest
                {
                    Amount = convertedAmount,
                    FromCurrency = request.FromCurrency,
                    ToCurrency = request.ToCurrency,

                };
                return Ok(response);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = new { code = "INVALID_CURRENCY", message = ex.Message } });
            }
        }

        public class ConversionRequest
        {
            public decimal Amount { get; set; }
            public string FromCurrency { get; set; }
            public string ToCurrency { get; set; }
        }
    }
}
