﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Core.Models;

namespace CurrencyConverter.Core.Interfaces
{
    public interface ICurrencyService
    {
        Task<IEnumerable<CurrencyRate>> GetCurrencyRatesAsync();
        Task<decimal> ConvertCurrencyAsync(decimal amount, string fromCurrency, string toCurrency);
    }
}