﻿using System.Text.Json;
using Core.Models;
using CurrencyConverter.Core.Interfaces;

namespace CurrencyConverter.Infrastructure.Services
{
    public class CurrencyService : ICurrencyService
    {
        private readonly HttpClient _httpClient;

        public CurrencyService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IEnumerable<CurrencyRate>> GetCurrencyRatesAsync()
        {
            string url = "https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/en/json/?date=" + DateTime.UtcNow.ToString("yyyy-MM-dd");
            var response = await _httpClient.GetStringAsync(url);
            var currencyResponse = JsonSerializer.Deserialize<List<ConversionResponse>>(response);

            if (currencyResponse == null || !currencyResponse.Any())
                throw new InvalidOperationException("API response does not contain valid currency data.");

            return currencyResponse.First().Currencies;
        }

        public async Task<decimal> ConvertCurrencyAsync(decimal amount, string fromCurrency, string toCurrency)
        {
            var rates = await GetCurrencyRatesAsync();

            var fromRate = rates.SingleOrDefault(r => r.Code.Equals(fromCurrency, StringComparison.OrdinalIgnoreCase));
            var toRate = rates.SingleOrDefault(r => r.Code.Equals(toCurrency, StringComparison.OrdinalIgnoreCase));

            if (fromRate == null || toRate == null)
                throw new ArgumentException("Invalid currency code.");

            var amountInGel = (amount * fromRate.Rate) / fromRate.Quantity;
            return Math.Round((amountInGel / (toRate.Rate / toRate.Quantity)), 4);
        }
    }
}